# Memory Mansion — teammate handoff

This is a separate editable copy of the latest published app (version 7), including the 100° horizontal first-person FOV. The original live Site is not modified by this export.

## Start with ChatGPT
Upload this ZIP to your own ChatGPT conversation with Sites enabled. Paste:

> This ZIP contains the source of our NetworkIQ: Memory Mansion app. Read START_HERE.md and README.md, then use this existing implementation as the starting point. Create a NEW, separate Site for previewing my changes; do not update any existing Site. Preserve existing features and saved-data compatibility. First ask which changes I want. After making them, run npm test and check the relevant interactions. Return the complete updated source as a ZIP, including CHANGELOG_TEAMMATE.md describing changed files, checks and any limitations. Keep HANDOFF_BASE.json unchanged so my teammate can compare and merge my changes into the original project. Email integration remains on hold.

If ZIP inspection is unavailable, extract it and upload the relevant files. A preview Site depends on the capabilities available in your account.

## Run locally (optional)
From the extracted project folder, run:

    python3 -m http.server 8080 --directory dist

On Windows, `py -m http.server 8080 --directory dist` also works with Python installed. Open http://localhost:8080. Serve through HTTP rather than double-clicking index.html.

The app uses plain JavaScript modules, HTML, CSS and original SVG artwork. The editable source is in dist/; no build or dependency installation is needed. With a recent Node.js version installed, run `npm test` from the project folder.

## Return your changes
1. Agree which features you will edit to reduce conflicts.
2. Edit the included implementation, retaining existing localStorage keys and compatible profile fields.
3. Document changes and checks in CHANGELOG_TEAMMATE.md.
4. ZIP the complete project folder, excluding .git, node_modules, credentials and local configuration.
5. Send the ZIP back to Shaun. He can upload it to the original conversation and ask to review, merge, verify and publish it to the original Site.

Changes do not synchronise automatically. The original project may have progressed since this export; compare against HANDOFF_BASE.json before merging. Do not blindly replace newer files.

## Data and hosting
This package includes fictional demonstration profiles, not browser-saved contacts, photographs, activities or preferences. Each preview origin has separate browser storage. Automatic email and central spreadsheet synchronisation are not implemented.

The original Site's hosting identity and Git metadata are deliberately omitted. When creating a new Site, let Sites generate a fresh hosting manifest and project identity. Keep the original publishing credentials out of this copy.
