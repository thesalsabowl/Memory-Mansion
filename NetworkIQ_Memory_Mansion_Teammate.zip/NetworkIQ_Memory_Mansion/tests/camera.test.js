import test from 'node:test';
import assert from 'node:assert/strict';
import {turnCamera,cameraPoint,PITCH_LIMIT} from '../dist/camera.js';
test('yaw wraps freely through repeated complete turns in both directions',()=>{let y=0;for(let i=0;i<40;i++)y=turnCamera(y,0,Math.PI/4,0).yaw;assert.ok(Math.abs(y)<1e-9||Math.abs(y-Math.PI*2)<1e-9);assert.ok(Math.abs(turnCamera(0,0,-Math.PI/2,0).yaw-Math.PI*1.5)<1e-9);});
test('look up and down is limited just before the poles without flipping',()=>{assert.equal(turnCamera(0,0,0,99).pitch,PITCH_LIMIT);assert.equal(turnCamera(0,0,0,-99).pitch,-PITCH_LIMIT);});
test('camera projection changes in every direction and full rotation returns to same view',()=>{const pos={x:10,y:10},p=[30,10,41],a=cameraPoint(p,pos,0,0);assert.equal(a.z,20);assert.equal(a.y,10);assert.ok(cameraPoint(p,pos,0,.4).y<a.y);assert.ok(cameraPoint(p,pos,0,-.4).y>a.y);assert.ok(cameraPoint(p,pos,Math.PI/2,0).x<0);assert.ok(cameraPoint(p,pos,-Math.PI/2,0).x>0);const b=cameraPoint(p,pos,2*Math.PI,0);assert.ok(Math.abs(a.z-b.z)<1e-9);});
