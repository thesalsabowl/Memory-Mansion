# NetworkIQ: Memory Mansion
Turn connections into unforgettable memories.

## Run
Serve `dist/` with any static HTTP server (for example `python3 -m http.server 8080 --directory dist`). Open the server URL. No installation, API key or build step is required. For a Sites preview use `sites-preview start /workspace/sites/networkiq-memory-mansion`.

## Implementation
- Original SVG isometric dollhouse with six furnished spaces and 51 placement slots (16 in the grand garden).
- Browser-native ES modules and responsive CSS; dependency-free alternative to the preferred React stack.
- `dist/model.js`: room definitions, five fictional demo profiles, deterministic mnemonic generation, validation and storage.
- `dist/art.js`: original room geometry, furniture, eight object illustrations and icons.
- `dist/app.js`: mansion navigation, one-page contact editor, journal, profile detail, moving, unplacing, deletion and photo processing.
- `dist/style.css`: responsive design, motion and reduced-motion support.
- `tests/`: domain and form interaction regression tests. Run `npm test`.

Profiles are saved in localStorage under `networkiq-mansion-v1`. They belong to this browser and origin, not an online account. Clearing site data removes them. Blocked/full storage reports an error without claiming a save. Invalid saved records are protected from automatic overwrite and can be downloaded for recovery. Uploaded images are resized to 200px and stored locally.

## Mnemonics
This build uses the specified working template fallback, explicitly labelled in the interface. It does not make external LLM calls. Repeated generation cycles through four imaginative actions, while selecting an object based on supplied cues. The user can rewrite the scene and choose from eight visual objects. Imagined scenes are not factual claims.

## Five-minute demo
1. (0:00–0:40) Explain: meeting someone is easy; remembering their small details is harder. Open the mansion and show its six spaces.
2. (0:40–1:20) Open Alex's talking apple in the kitchen. Show the fictional person and imagined scene.
3. (1:20–2:20) Add fictional person Casey Rivers, a robotics researcher who loves tea, met at a campus showcase. Add a memorable detail and conversation note.
4. (2:20–3:10) Generate a scene. Explain the local template fallback; edit the wording and choose an object.
5. (3:10–3:50) Choose the study and an empty armchair. Save and place the memory.
6. (3:50–4:30) Click the new object, reveal the profile and notes. Refresh to demonstrate persistence.
7. (4:30–5:00) Open the collection book, search Casey, then move the memory to a garden bench. Close: “A place for every connection.”

## Scope
No quizzes, points, scores, schedules, outreach, relationship ratings, career recommendations or autonomous agents. The experience is collection and exploration only. No proprietary artwork or remote runtime assets.

## Playable explorer
Customise your explorer from the toolbar: name, skin tone, hair colour/style, outfit colour and accessory. Settings persist separately from people. Use W/A/S/D to walk in screen directions, E to interact, or press/hold the on-screen arrows. Walk across the connecting paths to reach adjoining rooms; press E near a connection to open its wardrobe. Typing inside a form pauses movement.

Little errands invite you to fill missing details for people in the current room. Choose an errand to highlight its memory, walk nearby, press E and enter a detail you know. It is saved to the existing person's profile and the next available prompt appears. Existing facts are never overwritten by these tasks. There are no points or recall tests. All 51 memory locations and every doorway remain reachable around furniture.

## Whole-mansion walking and memory outfits
WASD now moves continuously across the entire mansion overview. Use the pale connecting walkways between rooms; press E at a closed door to open it. Movement from a focused room returns to the overview at the same location. E opens a nearby memory's wardrobe.

Each connection has three combinable accessories: message → golden bow tie, follow-up → explorer scarf, meeting or call → top hat. Record an activity with its date, a note and confirmation that you completed it, then choose Dress object. The activity log is self-reported; the app never sends messages or verifies external actions. Unlocks and outfits belong to that connection and persist with its profile. Take off removes an equipped decoration without removing the recorded activity. The prior missing-detail errands remain available from the wardrobe.

### First-person exploration and doors

- `+` zooms through 150% and 200% into an eye-level perspective. `F` or the view button switches directly between first person and the dollhouse without moving the avatar.
- WASD moves on the floor. In first person, W/S move forwards/backwards and A/D strafe. Left/right arrow keys, dragging the scene, or touch look buttons turn the camera.
- E (or Interact) opens/closes a nearby door. All nine connecting doors start closed. A doorway cannot close on the avatar. Door state lasts for the current page session.
- The shared world geometry provides floor bounds, avatar clearance, solid walls/furniture and closed-door collisions. Room navigation inspects rooms without teleporting the avatar. The first-person minimap shows position, heading and door state.
- Original SVG memory objects, including their earned accessories, appear in the perspective scene. E opens their wardrobe within the same room.

Checks: `node --test tests/*.test.js` (31 tests). Browser QA covers blocked doors, opening and walking between rooms, zoom-to-first-person, and unchanged position when switching views.

### Full look and richer interiors

First person supports unrestricted 360° yaw and pitch up/down to ±86.6° using two-axis dragging, all four arrow keys, and touch buttons. Free look requests pointer lock where supported, with drag/keyboard fallback and Esc release. The level-camera button resets pitch. Looking never changes floor collision or movement height.

The perspective renderer now adds directional face shading, plank/tile floors, patterned rugs, wall panelling, ceiling panels, framed artwork, glowing lamps, cushions, surface books/mugs, kitchen fixtures, a computer display, garden flowers and fountain droplets. Memory objects gently float and glow; footsteps add light camera and sleeve motion. Reduced-motion settings disable these animations.

Validation: 34 automated tests, plus browser checks for full rotation, positive/negative pitch, two-axis drag and camera reset. Pointer lock is blocked in the QA browser; its fallback was verified.

## A larger, personal home

The mansion includes a new conservatory, expanded garden, original framed wall art, pergola, plants and paths. All 51 avatar slots are reachable with floor-only movement.

Create a connection on one page with first name, last name and either a valid email or phone number. Extra profile fields and mnemonic controls are optional expandable sections. Existing demo profiles remain editable without newly required contact details.

Background choices are original forest, eggshell white, light blue, pastel pink and soft lavender. Sunny, cloudy and rain are chosen visual ambience rather than live weather. Decorate changes the 31 added display spots between tables, armchairs, botanical stands and pedestals, with four finishes; original furnishings remain fixed. Preferences persist in `networkiq-home-v2`.

Play lo-fi starts an original browser-synthesised instrumental loop with pause and volume controls. It requires a user click and never autoplays. No audio assets or external services are used.

Validation for this update: 40 passing tests, including contact validation, preference persistence failures, occupied slots, one-page submission and reachability of every slot. Browser checks verified email-only creation, refreshed appearance/furniture settings, and music play/pause controls.
